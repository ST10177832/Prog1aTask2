/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tests;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author User
 */
public class MessageTest {
    
}
    

